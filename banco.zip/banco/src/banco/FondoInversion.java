package banco;

public class FondoInversion extends cuenta{
	public FondoInversion (double saldo, double interes_cuenta, double comision, cliente c1) {
		super(saldo, interes_cuenta, comision, c1);
	}
	public void revisionMensual(cliente c1) {
		comision=0.6;
		interes_cuenta=saldo*0.034;
		saldo=saldo + interes_cuenta - comision;
	}
	public void sacarDinero(cliente c1) {
		if (dineror<=saldo) {
			saldo=saldo-dineror;
			System.out.println("Operaci�n realizada con exito");
		}
		else {
			System.out.println("La operaci�n no puede realizarse");
		}
	}
}
