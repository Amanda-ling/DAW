package banco;

public class CuentaVivienda extends cuenta{
	public CuentaVivienda (double saldo, double interes_cuenta, double comision, cliente c1) {
		super(saldo, interes_cuenta, comision, c1);
	}
	public void revisionMensual(cliente c1) {
			interes_cuenta=saldo*0.02;
			saldo=saldo + interes_cuenta;
		
	}
	public void sacarDinero(cliente c1) {
		System.out.println("No se puede retirar dinero");}
	
}
