package banco;

import java.util.Scanner;

public class principal{
private static cuenta Arraycuentas[]= new cuenta[1000];
private static cliente Arraycliente[] = new cliente[1000];
private static String DNI, nombre, apellidos, direccion, tipo;
private static int telefono;
private static double saldo, interes_cuenta, comision;
private static int menu;
	public static void main(String[] args) {
		System.out.println(" Seleccione el numero de la operaci�n a realizar:");
		System.out.println("1.Nuevo cliente");
		System.out.println("2.Nueva cuenta");
		System.out.println("3.Listar clientes y cuentas");
		System.out.println("4.Ingresar dinero");
		System.out.println("5.Sacar dinero");
		System.out.println("6.Consultar saldo");
		System.out.println("7.Revisi�n mensual");
		System.out.println("8.Cambiar comision mensual");
		System.out.println("0.Salir");
		Scanner sc= new Scanner(System.in);
		menu=sc.nextInt();
		switch(menu) {
		/*opcion nuevo cliente*/
		case 1:
			int longitud;
			int i;
			if(longitud<1000) {
				System.out.println("Introduce el DNI");
				DNI=sc.next();
				System.out.println("Introduce el nombre");
				nombre=sc.next();
				System.out.println("Introduce apellidos");
				apellidos=sc.next();
				System.out.println("Introduce direccion");
				direccion=sc.next();
				System.out.println("Introduce telefono");
				telefono=sc.nextInt();	
			Arraycliente[i]= new cliente(DNI, nombre, apellidos, direccion, telefono);
			i=i+1;
			longitud=i;
					}
			break;
			
		/*opcion nueva cuenta*/	
		case 2:
			for( i=0; longitud<1000; i++) {
				System.out.println("Dame el dni");
				DNI=sc.next();
				if(Arraycliente[i].getDNI()==DNI) {
					System.out.println("Introduce el saldo");
					saldo=sc.nextDouble();
					System.out.println("Introduce el interes de la cuenta");
					interes_cuenta=sc.nextDouble();
					System.out.println("Introduce comision");
					comision=sc.nextDouble();
					System.out.println("Introduce tipo de cuenta");
					tipo=sc.next();
					if (tipo.equals("CC")) {
						Arraycuentas[i] = new CuentaCorriente(saldo, interes_cuenta, comision, Arraycliente[i]);	
					}
					if (tipo.equals("CV")) {
						Arraycuentas[i] = new CuentaVivienda(saldo, interes_cuenta, comision, Arraycliente[i]);	
					}
					if (tipo.equals("CC")) {
						Arraycuentas[i] = new FondoInversion(saldo, interes_cuenta, comision, Arraycliente[i]);	
					}
					
				}
				longitud=i;
			}
			break;
			
		/*opcion listar*/	
		case 3:
			for(int i=0; longitud<1000; i++) {
				Arraycliente[i].imprimir();
				
				}
			break;
			
		/*opcion ingresar*/	
		case 4:
			System.out.println("En que cuenta?");
			n_cuenta=sc.nextInt();
			break;
		/*opcion sacar*/	
		case 5:
			System.out.println("En que cuenta?");
			break;
		/*opcion consultar saldo*/
		case 6:
			System.out.println("De que cuenta?");
			break;
		/*opcion revsi�n*/
		case 7:
			System.out.println("De que cuenta?");
			break;
		/*opcion cambiar comision*/
		case 8:
			System.out.println("En que cuenta?");
			break;
			
		/*salir*/
		case 0:
			break;
		
		}

	}
	

}
