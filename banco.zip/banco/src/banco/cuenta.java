package banco;

public abstract class cuenta{
protected double saldo, interes_cuenta, comision, dineror, dineroi;
protected String tcuenta;
protected cliente c1;

public cuenta(double saldo, double interes_cuenta, double comision, cliente c1) {
	this.saldo=saldo;
	this.interes_cuenta=interes_cuenta;
	this.comision=comision;
	this.c1=c1;
}

public double ingresarDinero(cliente c1) {
	saldo=saldo+dineroi;
	return saldo;
}
public abstract void sacarDinero(cliente c1);

public  void consultarSaldo(cliente c1) {
	System.out.println("Su saldo es: " + saldo);
}
public abstract void revisionMensual(cliente c1);

}
