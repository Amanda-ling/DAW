
public class pelicula extends Producto{
private int a�o;
private String director;
private String interpretes[] = new String[100];
private String tipo="pelicula";
public pelicula(String titulo, double precio_alquiler, boolean alquilado, int referencia,
		int plazo_alquiler, int a�o, String director, String[] interpretes) {
	super(titulo, precio_alquiler, alquilado, referencia, plazo_alquiler);
	this.a�o = a�o;
	this.director = director;
	this.interpretes = interpretes;
}

}
