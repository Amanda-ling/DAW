
public class RegistroAlquiler {
	private cliente ArrayCliente[] = new cliente[1000];
	private Producto ArrayProducto[] = new Producto[1000];
	private String fecha_alquiler, fecha_devol;
	private double importe;
	public RegistroAlquiler(String fecha_alquiler, String fecha_devol, double importe) {
		super();
		this.fecha_alquiler = fecha_alquiler;
		this.fecha_devol = fecha_devol;
		this.importe = importe;
	}
	
	
}
