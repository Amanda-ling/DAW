
public class cliente {
private int numCliente, telefono;
private String nombre, direccion;
private Producto ProductosAlquilados[]= new Producto[1000];
public cliente(int numCliente, int telefono, String nombre, String direccion, Producto[] productosAlquilados) {
	this.numCliente = numCliente;
	this.telefono = telefono;
	this.nombre = nombre;
	this.direccion = direccion;
	ProductosAlquilados = productosAlquilados;
}
/**
 * @return the numCliente
 */
public int getNumCliente() {
	return numCliente;
}
/**
 * @param numCliente the numCliente to set
 */
public void setNumCliente(int numCliente) {
	this.numCliente = numCliente;
}
/**
 * @return the telefono
 */
public int getTelefono() {
	return telefono;
}
/**
 * @param telefono the telefono to set
 */
public void setTelefono(int telefono) {
	this.telefono = telefono;
}
/**
 * @return the nombre
 */
public String getNombre() {
	return nombre;
}
/**
 * @param nombre the nombre to set
 */
public void setNombre(String nombre) {
	this.nombre = nombre;
}
/**
 * @return the direccion
 */
public String getDireccion() {
	return direccion;
}
/**
 * @param direccion the direccion to set
 */
public void setDireccion(String direccion) {
	this.direccion = direccion;
}
/**
 * @return the productosAlquilados
 */
public Producto[] getProductosAlquilados() {
	return ProductosAlquilados;
}
/**
 * @param productosAlquilados the productosAlquilados to set
 */
public void setProductosAlquilados(Producto[] productosAlquilados) {
	ProductosAlquilados = productosAlquilados;
	
}
public void imprimir() {
	System.out.println("----------cliente------");
	System.out.println(numCliente);
	System.out.println(nombre);
	System.out.println(direccion);
	System.out.println(telefono);
	System.out.println(ProductosAlquilados);
}


}
