
public enum Estilo {
	ACCION, DEPORTES, AVENTURAS, PUZLE, INFANTIL
}
