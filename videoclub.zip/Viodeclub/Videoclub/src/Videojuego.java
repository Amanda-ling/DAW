
public class Videojuego extends Producto {
	private String tipo="videojuego";
	public Videojuego(String titulo, double precio_alquiler, boolean alquilado, int referencia,
			int plazo_alquiler) {
		super(titulo, precio_alquiler, alquilado, referencia, plazo_alquiler);
		
	}

}
