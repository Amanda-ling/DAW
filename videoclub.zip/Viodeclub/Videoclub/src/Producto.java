import banco.cliente;
import banco.cuenta;

public class Producto {
	private String titulo, tipo;
	private double precio_alquiler;
	private boolean alquilado;
	private int referencia, plazo_alquiler;
	
public Producto(String titulo, double precio_alquiler, boolean alquilado,int referencia, int plazo_alquiler) {
		this.titulo = titulo;
		this.precio_alquiler = precio_alquiler;
		this.alquilado = alquilado;
		this.referencia=referencia;
		this.plazo_alquiler = plazo_alquiler;
	}


public String getTitulo() {
	return titulo;
}


public void setTitulo(String titulo) {
	this.titulo = titulo;
}

public int getReferencia() {
	return referencia;
}


public void setReferencia(int  referencia) {
	this.referencia = referencia;
}


public double getPrecio_alquiler() {
	return precio_alquiler;
}


public void setPrecio_alquiler(double precio_alquiler) {
	this.precio_alquiler = precio_alquiler;
}


public boolean isAlquilado() {
	return alquilado;
}


public void setAlquilado(boolean alquilado) {
	this.alquilado = alquilado;
}

public int getPlazo_alquiler() {
	return plazo_alquiler;
}

public void setPlazo_alquiler(int plazo_alquiler) {
	this.plazo_alquiler = plazo_alquiler;
}

public void imprimir() {
	System.out.println("----------producto------");
	System.out.println(referencia);
	System.out.println(titulo);
	System.out.println();
	System.out.println(precio_alquiler);
	System.out.println(plazo_alquiler);
	System.out.println(alquilado);

}
}

