import java.util.Scanner;

import banco.cliente;
import banco.cuenta;

public class aplicacionVideoclub {
private static int menu, telf, ncliente, ref, i=0, cont=0;
private static String nombre, direccion;
private static Producto Arrayproductos[]= new Producto[1000];
private static cliente Arraycliente[] = new cliente[1000];
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		while (menu!=0) {
		System.out.println(" Seleccione el numero de la operaci�n a realizar:");
		System.out.println("1.Lista productos");
		System.out.println("2.Ficha producto");
		System.out.println("3.Listar clientes");
		System.out.println("4.A�adir cliente ");
		System.out.println("5.Ficha cliente");
		System.out.println("6.Alquilar producto");
		System.out.println("7.Listado de registro de alquiler");
		System.out.println("0.Salir");
		menu=sc.nextInt();
		
		switch(menu) {
		/*opcion listar productos*/
		case 1:
			for(int x=0; x<i; x++) {
				Arrayproductos[x].imprimir();
			}
			break;
			
			/*opcion ficha productos*/
		case 2:
			System.out.println("Introduce la referencia del producto a mostrar");
			ref=sc.nextInt();
			Arrayproductos[ref].imprimir();
			break;
			
			/*opcion listar clientes*/
		case 3:
			for(int x=0; x<i; x++) {
				Arraycliente[x].imprimir();
			}
			break;
			
			/*opcion a�adir clientes*/
		case 4:
			for(int i=0; i<cont; i++) {
					Arraycliente[i].setNumCliente(i);
					System.out.println("Introduce el nombre");
					nombre=sc.next();
					System.out.println("Introduce direccion");
					direccion=sc.next();
					System.out.println("Introduce telefono");
					telf=sc.nextInt();
					Arraycliente[i].setProductosAlquilados(); /*revisar esto*/
					cont++;
				}
			break;
			
			/*opcion ficha cliente*/
		case 5:
			System.out.println("Introduce el numero de cliente a mostrar");
			ncliente=sc.nextInt();
			Arraycliente[ncliente].imprimir();
			break;
			
			/*opcion alquilar producto*/
		case 6:
			System.out.println("Introduzca el numero de cliente");
			ncliente=sc.nextInt();
			System.out.println("Introduzca que producto desea alquilar");
			ref=sc.nextInt();
			if (Arrayproductos[ref].isAlquilado()==false) {
			Arrayproductos[ref].setAlquilado(true);                         /*hay que introducir los datos en el registro de alquiler*/
			/*el alquiler se realiza durante 7 dias*/
			Arrayproductos[ref].setPlazo_alquiler(7);}
			
			break;
			
			/*opcion listar registro alquiler*/
		case 7:
			break;
			
			/*opcion salir*/
		case 0:
			break;
		}
		}
		}
	}
