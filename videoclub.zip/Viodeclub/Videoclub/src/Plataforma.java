
public enum Plataforma {
	XBOX,PLAYSTATION, WII
}
