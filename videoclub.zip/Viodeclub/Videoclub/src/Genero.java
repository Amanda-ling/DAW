
public enum Genero {
	ACCI�N, DRAMA, DEPORTES, AVENTURAS, INFANTIL
}
